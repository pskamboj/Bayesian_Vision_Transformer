
// --- Diagram Components (New) ---

const DiagramBlock = ({ title, children, className = "", active = false }) => (
    <div className={`diagram-block ${active ? 'active' : ''} ${className}`}>
        <div className="diagram-header">{title}</div>
        <div className="diagram-content">
            {children}
        </div>
    </div>
);

const ArchitecturalView = () => {
    return (
        <div className="architecture-container">
            {/* Column 1: Input & Embeddings */}
            <div className="arch-column col-input">
                <h3 className="col-title">1. Input & Embedding</h3>
                <DiagramBlock title="Input Image (224x224)" active={storyStep >= 0}>
                    <div className="relative w-24 h-24 mx-auto border border-blue-400/50">
                        <img src={image} className="w-full h-full object-cover opacity-80" alt="Input" />
                        {storyStep >= 1 && (
                            <div className="absolute inset-0 grid grid-cols-14 gap-px bg-black/20">
                                {[...Array(196)].map((_, i) => <div key={i} className="bg-white/5"></div>)}
                            </div>
                        )}
                    </div>
                </DiagramBlock>

                <div className="arch-arrow-down" />

                <DiagramBlock title="Patch Embedding (16x16)" active={storyStep >= 1}>
                    <div className="text-center text-xs text-blue-300 mb-2">Flattened 196 Patches</div>
                    <div className="flex justify-center gap-1 flex-wrap px-2">
                        {[...Array(12)].map((_, i) => (
                            <div key={i} className="w-2 h-6 bg-pink-500/40 rounded-sm"></div>
                        ))}
                        <span className="text-xs text-gray-500">...</span>
                    </div>
                </DiagramBlock>

                <div className="arch-arrow-down" />

                <DiagramBlock title="Add [CLS] Token" active={storyStep >= 1}>
                    <div className="flex items-center justify-center gap-2">
                        <div className="w-6 h-6 rounded bg-yellow-500/80 text-black text-[10px] font-bold flex items-center justify-center">CLS</div>
                        <span className="text-lg">+</span>
                        <div className="text-xs text-gray-400">Pos Embed</div>
                    </div>
                </DiagramBlock>
            </div>

            {/* Column 2: Transformer Blocks */}
            <div className="arch-column col-transformer">
                <h3 className="col-title">2. Transformer Blocks (xL)</h3>

                <div className="transformer-stack border-l-2 border-dashed border-gray-700 ml-4 pl-4 relative">
                    <div className="absolute -left-1.5 top-1/2 -translate-y-1/2 w-3 h-3 bg-gray-700 rounded-full"></div>

                    <DiagramBlock title="Bayesian Transformer Block" className="w-full" active={storyStep >= 2}>

                        {/* Norm 1 */}
                        <div className="sub-block mb-2">Layer Norm 1</div>

                        {/* MHA */}
                        <div className="sub-block bg-blue-900/20 border-blue-500/30 p-2 mb-2">
                            <div className="text-[10px] text-blue-300 mb-1">Bayesian Multi-Head Attention</div>
                            <div className="flex justify-center gap-4">
                                <div className="w-6 h-6 rounded-full border border-pink-400 flex items-center justify-center text-[8px]">Q</div>
                                <div className="w-6 h-6 rounded-full border border-pink-400 flex items-center justify-center text-[8px]">K</div>
                                <div className="w-6 h-6 rounded-full border border-pink-400 flex items-center justify-center text-[8px]">V</div>
                            </div>
                        </div>

                        {/* Residual 1 */}
                        <div className="text-xs text-gray-500 text-right mb-2">↳ Residual Connection</div>

                        {/* Norm 2 */}
                        <div className="sub-block mb-2">Layer Norm 2</div>

                        {/* MLP */}
                        <div className="sub-block bg-blue-900/20 border-blue-500/30 p-2">
                            <div className="text-[10px] text-blue-300 mb-1">Bayesian MLP</div>
                            <div className="flex justify-center gap-2 text-[8px]">
                                <div className="px-2 py-1 border border-gray-600 rounded">FC1 (Bayes)</div>
                                <div className="px-2 py-1 border border-gray-600 rounded">GELU</div>
                                <div className="px-2 py-1 border border-gray-600 rounded">FC2 (Bayes)</div>
                            </div>
                        </div>
                    </DiagramBlock>
                </div>
            </div>

            {/* Column 3: Output Head */}
            <div className="arch-column col-head">
                <h3 className="col-title">3. Output Head</h3>
                <div className="mt-12 flex flex-col items-center gap-4">
                    <DiagramBlock title="Final Layer Norm" active={storyStep >= 4}>
                        <div className="w-24 h-6 bg-gray-700/50 rounded"></div>
                    </DiagramBlock>

                    <div className="arch-arrow-down" />

                    <DiagramBlock title="Extract [CLS]" active={storyStep >= 4}>
                        <div className="w-8 h-8 rounded bg-yellow-500/80 text-black text-xs font-bold flex items-center justify-center mx-auto">CLS</div>
                    </DiagramBlock>

                    <div className="arch-arrow-down" />

                    <DiagramBlock title="Bayesian Output Layer" active={storyStep >= 4}>
                        <div className="text-[10px] text-center mb-1">Linear (D → 4 Classes)</div>
                        <div className="grid grid-cols-4 gap-1">
                            {[...Array(4)].map((_, i) => <div key={i} className="w-4 h-4 rounded-full border border-green-500/50"></div>)}
                        </div>
                    </DiagramBlock>
                </div>
            </div>

            {/* Column 4: Prediction */}
            <div className="arch-column col-pred">
                <h3 className="col-title">4. Prediction & Uncertainty</h3>

                <DiagramBlock title="Monte Carlo Sampling (T=5)" active={storyStep >= 4} className="mb-4">
                    <div className="opacity-50 text-[10px] text-center mb-1">Simulated Forward Passes</div>
                    <div className="space-y-1">
                        {[...Array(5)].map((_, i) => (
                            <div key={i} className="h-1 w-full bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-30"></div>
                        ))}
                    </div>
                </DiagramBlock>

                <div className="arch-arrow-down" />

                <DiagramBlock title="Softmax & Ensemble" active={storyStep >= 4}>
                    <div className="text-center text-xl font-bold mb-2">{results.predicted_label}</div>
                    <div className="space-y-2">
                        {results.class_names.map((name, idx) => (
                            <div key={idx} className="flex justify-between text-xs">
                                <span className={idx === results.predicted_class ? "text-green-400" : "text-gray-500"}>{name}</span>
                                <span>{(results.probabilities[idx] * 100).toFixed(1)}%</span>
                            </div>
                        ))}
                    </div>
                </DiagramBlock>

                {/* Stats Bell Curve */}
                <div className="mt-4">
                    <div className="text-[10px] text-yellow-500 mb-1">Uncertainty Quantification</div>
                    <BellCurveChart mu={results.layer_stats.mu} sigma={results.layer_stats.sigma} sampled={results.layer_stats.sampled} />
                </div>
            </div>

        </div>
    );
};
