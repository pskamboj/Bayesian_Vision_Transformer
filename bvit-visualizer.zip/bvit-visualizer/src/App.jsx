import React, { useState, useEffect, useRef } from 'react';
import { Upload, Brain, Zap, Eye, Layers, Activity, ArrowRight, ChevronRight, CheckCircle, AlertCircle, X, Settings } from 'lucide-react';

const BayesianViTVisualizer = () => {
  const [step, setStep] = useState(0);
  const [activeStage, setActiveStage] = useState(null);
  const [image, setImage] = useState(null);
  const [imageData, setImageData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [selectedPatch, setSelectedPatch] = useState(0);
  const [selectedLayer, setSelectedLayer] = useState(0);
  const [backendUrl, setBackendUrl] = useState('http://localhost:5500');
  const [backendStatus, setBackendStatus] = useState('checking');
  const fileInputRef = useRef(null);
  const [hoveredBlock, setHoveredBlock] = useState(null);
  const [showPatchDetail, setShowPatchDetail] = useState(false);
  const [patchDetailStep, setPatchDetailStep] = useState(0);
  const [extractedPatches, setExtractedPatches] = useState([]);
  const [showTransformerDetail, setShowTransformerDetail] = useState(false);
  const [transformerDetailStep, setTransformerDetailStep] = useState(0);
  const [showOutputDetail, setShowOutputDetail] = useState(false);
  const [outputDetailStep, setOutputDetailStep] = useState(0);
  const [showPredictionDetail, setShowPredictionDetail] = useState(false);
  const [predictionDetailStep, setPredictionDetailStep] = useState(0);

  useEffect(() => {
    checkBackendHealth();
  }, [backendUrl]);

  useEffect(() => {
    if (image && showPatchDetail) {
      extractPatchesFromImage();
    }
  }, [image, showPatchDetail]);

  const checkBackendHealth = async () => {
    try {
      const response = await fetch(`${backendUrl}/api/health`);
      if (response.ok) {
        setBackendStatus('connected');
      } else {
        setBackendStatus('error');
      }
    } catch (error) {
      setBackendStatus('error');
    }
  };

  const extractPatchesFromImage = () => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 256;
      canvas.height = 256;
      ctx.drawImage(img, 0, 0, 256, 256);

      const patches = [];
      const patchSize = 16;
      for (let i = 0; i < 16; i++) {
        for (let j = 0; j < 16; j++) {
          const x = j * patchSize;
          const y = i * patchSize;
          const imageData = ctx.getImageData(x, y, patchSize, patchSize);
          const smallCanvas = document.createElement('canvas');
          smallCanvas.width = patchSize;
          smallCanvas.height = patchSize;
          const smallCtx = smallCanvas.getContext('2d');
          smallCtx.putImageData(imageData, 0, 0);
          patches.push(smallCanvas.toDataURL());
        }
      }
      setExtractedPatches(patches);
    };
    img.src = image;
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target.result);
        setImageData(e.target.result);
        setStep(1);
        setResults(null);
        setActiveStage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = async () => {
    if (!imageData) return;

    setLoading(true);
    setStep(2);

    try {
      const response = await fetch(`${backendUrl}/api/predict`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: imageData })
      });

      if (!response.ok) throw new Error('Prediction failed');

      const data = await response.json();
      setResults(data);
      setStep(3);
      setActiveStage(1);
    } catch (error) {
      alert('Error: ' + error.message + '. Make sure the Flask backend is running.');
      setStep(1);
    } finally {
      setLoading(false);
    }
  };

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)',
      color: 'white',
      padding: '20px',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    },
    header: {
      textAlign: 'center',
      marginBottom: '40px',
      paddingTop: '20px'
    },
    title: {
      fontSize: '36px',
      fontWeight: 'bold',
      background: 'linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%)',
      WebkitBackgroundClip: 'text',
      WebkitTextFillColor: 'transparent',
      marginBottom: '12px'
    },
    subtitle: {
      fontSize: '16px',
      color: '#94a3b8',
      marginBottom: '24px'
    },
    uploadSection: {
      textAlign: 'center',
      marginBottom: '40px',
      maxWidth: '600px',
      margin: '0 auto 40px'
    },
    uploadBox: {
      background: 'rgba(30, 41, 59, 0.8)',
      border: '2px dashed rgba(148, 163, 184, 0.5)',
      borderRadius: '16px',
      padding: '40px',
      cursor: 'pointer',
      transition: 'all 0.3s ease'
    },
    flowContainer: {
      display: 'flex',
      gap: '16px',
      maxWidth: '1600px',
      margin: '0 auto',
      flexWrap: 'wrap'
    },
    stageBox: {
      flex: '1',
      minWidth: '280px',
      background: 'rgba(30, 41, 59, 0.8)',
      border: '2px solid rgba(148, 163, 184, 0.3)',
      borderRadius: '16px',
      padding: '20px',
      backdropFilter: 'blur(10px)',
      transition: 'all 0.3s ease',
      cursor: 'pointer',
      position: 'relative'
    },
    stageBoxActive: {
      border: '2px solid #3b82f6',
      boxShadow: '0 0 30px rgba(59, 130, 246, 0.4)',
      transform: 'scale(1.02)'
    },
    stageHeader: {
      fontSize: '18px',
      fontWeight: '700',
      marginBottom: '16px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      color: '#60a5fa'
    },
    stageNumber: {
      width: '32px',
      height: '32px',
      borderRadius: '50%',
      background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '16px',
      fontWeight: 'bold'
    },
    contentBox: {
      background: 'rgba(15, 23, 42, 0.6)',
      borderRadius: '12px',
      padding: '16px',
      marginBottom: '12px',
      border: '1px solid rgba(148, 163, 184, 0.2)'
    },
    patchGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: '3px',
      padding: '12px',
      background: 'rgba(15, 23, 42, 0.8)',
      borderRadius: '8px'
    },
    patch: {
      width: '100%',
      paddingBottom: '100%',
      position: 'relative',
      borderRadius: '3px',
      cursor: 'pointer',
      transition: 'all 0.2s ease'
    },
    patchInner: {
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      background: 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)',
      borderRadius: '3px',
      transition: 'all 0.2s ease'
    },
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      background: 'rgba(0, 0, 0, 0.7)',
      zIndex: 999,
      backdropFilter: 'blur(4px)'
    },
    detailPanel: {
      position: 'fixed',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      background: 'rgba(15, 23, 42, 0.98)',
      border: '2px solid #3b82f6',
      borderRadius: '16px',
      padding: '32px',
      maxWidth: '900px',
      width: '90%',
      maxHeight: '85vh',
      overflow: 'auto',
      zIndex: 1000,
      boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)'
    },
    arrow: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#60a5fa',
      fontSize: '24px',
      margin: '20px 0'
    },
    layerBlock: {
      background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(139, 92, 246, 0.2))',
      border: '1px solid rgba(59, 130, 246, 0.3)',
      borderRadius: '8px',
      padding: '12px',
      marginBottom: '8px',
      cursor: 'pointer',
      transition: 'all 0.3s ease'
    },
    layerBlockActive: {
      background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.4), rgba(139, 92, 246, 0.4))',
      border: '1px solid rgba(59, 130, 246, 0.6)',
      transform: 'scale(1.05)'
    },
    attentionGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(10, 1fr)',
      gap: '1px',
      background: '#0f172a',
      padding: '8px',
      borderRadius: '8px'
    },
    attentionCell: {
      paddingBottom: '100%',
      position: 'relative'
    },
    badge: {
      display: 'inline-block',
      padding: '4px 12px',
      borderRadius: '12px',
      fontSize: '11px',
      fontWeight: '600',
      marginTop: '8px'
    },
    progressBar: {
      height: '6px',
      background: '#1e293b',
      borderRadius: '3px',
      overflow: 'hidden',
      marginTop: '8px'
    },
    progressFill: {
      height: '100%',
      background: 'linear-gradient(90deg, #3b82f6, #8b5cf6)',
      transition: 'width 1s ease'
    }
  };

  const renderPatchDetailModal = () => {
    if (!showPatchDetail || !image) return null;

    const steps = [
      {
        title: "Step 1: Original Input Image",
        description: "The input MRI scan at full resolution (256×256 pixels). This grayscale image contains the brain structure we want to analyze.",
        visual: "original"
      },
      {
        title: "Step 2: Divide into Grid",
        description: "The image is divided into a 16×16 grid, creating 256 equal patches. Each patch is 16×16 pixels. This allows the model to process local features.",
        visual: "grid"
      },
      {
        title: "Step 3: Extract Individual Patches",
        description: "Each 16×16 pixel patch is extracted as a separate unit from your actual image. These patches will be processed independently and then combined.",
        visual: "patches"
      },
      {
        title: "Step 4: Flatten Patches",
        description: "Each 16×16 patch (256 pixels) is flattened into a 1D vector. This converts the 2D image data into a sequence format.",
        visual: "flatten"
      },
      {
        title: "Step 5: Linear Projection",
        description: "Each flattened patch is projected to embedding dimension D using a learned linear layer. This creates rich feature representations.",
        visual: "projection"
      },
      {
        title: "Step 6: Add CLS Token & Position",
        description: "A special [CLS] token is prepended, and positional embeddings are added to preserve spatial information. Now ready for transformer!",
        visual: "final"
      }
    ];

    const currentStep = steps[patchDetailStep];

    return (
      <>
        <div style={styles.overlay} onClick={() => setShowPatchDetail(false)} />
        <div style={styles.detailPanel}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '24px' }}>
            <div>
              <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '8px', color: '#60a5fa' }}>
                Patch Embedding Process
              </h2>
              <p style={{ fontSize: '14px', color: '#94a3b8' }}>
                Step {patchDetailStep + 1} of {steps.length}
              </p>
            </div>
            <button
              onClick={() => setShowPatchDetail(false)}
              style={{
                background: '#475569',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '8px 16px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <X size={16} />
              Close
            </button>
          </div>

          <div style={{ marginBottom: '24px' }}>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
              {steps.map((_, idx) => (
                <div
                  key={idx}
                  style={{
                    flex: 1,
                    height: '4px',
                    background: idx <= patchDetailStep ? 'linear-gradient(90deg, #3b82f6, #8b5cf6)' : '#1e293b',
                    borderRadius: '2px',
                    transition: 'all 0.3s ease'
                  }}
                />
              ))}
            </div>
          </div>

          <div style={{ background: 'rgba(30, 41, 59, 0.6)', borderRadius: '12px', padding: '24px', marginBottom: '24px' }}>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '12px', color: '#60a5fa' }}>
              {currentStep.title}
            </h3>
            <p style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6', marginBottom: '20px' }}>
              {currentStep.description}
            </p>

            <div style={{ background: '#0f172a', borderRadius: '8px', padding: '20px', minHeight: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {currentStep.visual === 'original' && (
                <div style={{ textAlign: 'center' }}>
                  <img src={image} alt="Original" style={{ maxWidth: '300px', maxHeight: '300px', borderRadius: '8px', border: '2px solid #3b82f6' }} />
                  <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '12px' }}>256×256 Grayscale Image</p>
                </div>
              )}

              {currentStep.visual === 'grid' && (
                <div style={{ position: 'relative', textAlign: 'center' }}>
                  <div style={{ position: 'relative', display: 'inline-block' }}>
                    <img src={image} alt="Grid" style={{ maxWidth: '300px', maxHeight: '300px', borderRadius: '8px', display: 'block' }} />
                    <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }} viewBox="0 0 256 256" preserveAspectRatio="none">
                      {[...Array(17)].map((_, i) => (
                        <React.Fragment key={i}>
                          <line x1={i * 16} y1="0" x2={i * 16} y2="256" stroke="#3b82f6" strokeWidth="1" opacity="0.6" />
                          <line x1="0" y1={i * 16} x2="256" y2={i * 16} stroke="#3b82f6" strokeWidth="1" opacity="0.6" />
                        </React.Fragment>
                      ))}
                    </svg>
                  </div>
                  <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '12px' }}>16×16 Grid = 256 Patches</p>
                </div>
              )}

              {currentStep.visual === 'patches' && (
                <div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: '4px', marginBottom: '12px' }}>
                    {extractedPatches.slice(0, 64).map((patchImg, i) => (
                      <img
                        key={i}
                        src={patchImg}
                        alt={`Patch ${i}`}
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '3px',
                          border: '1px solid #3b82f6',
                          imageRendering: 'pixelated'
                        }}
                      />
                    ))}
                  </div>
                  <p style={{ fontSize: '12px', color: '#94a3b8', textAlign: 'center' }}>Each patch: 16×16 pixels from your image (showing first 64)</p>
                </div>
              )}

              {currentStep.visual === 'flatten' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '20px' }}>
                    <div style={{ width: '80px', height: '80px', background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)', borderRadius: '8px', margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px', fontWeight: 'bold' }}>
                      16×16
                    </div>
                    <ArrowRight size={32} color="#60a5fa" style={{ margin: '0 auto', display: 'block' }} />
                  </div>
                  <div style={{ display: 'flex', gap: '2px', flexWrap: 'wrap', justifyContent: 'center', maxWidth: '400px' }}>
                    {[...Array(256)].map((_, i) => (
                      <div key={i} style={{ width: '6px', height: '20px', background: `rgba(59, 130, 246, ${0.3 + Math.random() * 0.7})`, borderRadius: '1px' }} />
                    ))}
                  </div>
                  <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '16px' }}>Flattened to 256-dimensional vector</p>
                </div>
              )}

              {currentStep.visual === 'projection' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '20px' }}>
                    <div style={{ padding: '16px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '8px', marginBottom: '16px' }}>
                      <p style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>Input: 256 pixels</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                        {[...Array(20)].map((_, i) => (
                          <div key={i} style={{ width: '8px', height: '30px', background: '#3b82f6', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                    <div style={{ fontSize: '20px', color: '#60a5fa', marginBottom: '16px' }}>↓ Linear Layer (W)</div>
                    <div style={{ padding: '16px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '8px' }}>
                      <p style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>Output: D dimensions</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                        {[...Array(30)].map((_, i) => (
                          <div key={i} style={{ width: '6px', height: '40px', background: '#8b5cf6', borderRadius: '1px', opacity: 0.4 + Math.random() * 0.6 }} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '12px', color: '#94a3b8' }}>Rich embedding space for learning</p>
                </div>
              )}

              {currentStep.visual === 'final' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center', justifyContent: 'center', marginBottom: '20px', flexWrap: 'wrap' }}>
                    <div style={{ width: '50px', height: '50px', background: 'linear-gradient(135deg, #10b981, #3b82f6)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', fontWeight: 'bold', border: '2px solid #10b981' }}>
                      CLS
                    </div>
                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                      {[...Array(12)].map((_, i) => (
                        <div key={i} style={{ width: '35px', height: '50px', background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', color: 'rgba(255,255,255,0.7)' }}>
                          P{i}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div style={{ background: 'rgba(59, 130, 246, 0.1)', padding: '12px', borderRadius: '8px', marginTop: '16px' }}>
                    <p style={{ fontSize: '12px', color: '#94a3b8' }}>+ Positional Embeddings</p>
                    <div style={{ display: 'flex', gap: '2px', marginTop: '8px', justifyContent: 'center', flexWrap: 'wrap' }}>
                      {[...Array(40)].map((_, i) => (
                        <div key={i} style={{ width: '6px', height: '16px', background: `rgba(168, 85, 247, ${0.3 + Math.random() * 0.7})`, borderRadius: '1px' }} />
                      ))}
                    </div>
                  </div>
                  <p style={{ fontSize: '13px', color: '#60a5fa', marginTop: '16px', fontWeight: '600' }}>
                    Sequence of 257 tokens × D dimensions
                  </p>
                </div>
              )}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
            <button
              onClick={() => setPatchDetailStep(Math.max(0, patchDetailStep - 1))}
              disabled={patchDetailStep === 0}
              style={{
                background: patchDetailStep === 0 ? '#1e293b' : '#475569',
                color: patchDetailStep === 0 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: patchDetailStep === 0 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              ← Previous
            </button>
            <button
              onClick={() => setPatchDetailStep(Math.min(steps.length - 1, patchDetailStep + 1))}
              disabled={patchDetailStep === steps.length - 1}
              style={{
                background: patchDetailStep === steps.length - 1 ? '#1e293b' : 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                color: patchDetailStep === steps.length - 1 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: patchDetailStep === steps.length - 1 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              Next →
            </button>
          </div>
        </div>
      </>
    );
  };

  const renderTransformerDetailModal = () => {
    if (!showTransformerDetail || !image || !results) return null;

    const steps = [
      {
        title: "Step 1: Input Token Sequence",
        description: "The transformer receives a sequence of 257 tokens (1 CLS + 256 patches), each with dimension D. These are the embedded representations from Stage 1.",
        visual: "input_sequence"
      },
      {
        title: "Step 2: Layer Normalization",
        description: "First, we apply Layer Normalization to stabilize the inputs. This normalizes across the feature dimension for each token independently.",
        visual: "layer_norm"
      },
      {
        title: "Step 3: Query, Key, Value Projection",
        description: "Each token is linearly projected into Query (Q), Key (K), and Value (V) matrices. These projections allow tokens to interact with each other.",
        visual: "qkv_projection"
      },
      {
        title: "Step 4: Multi-Head Attention - Computing Attention Scores",
        description: "We compute attention scores by taking the dot product of Q and K. This determines how much each patch should attend to every other patch.",
        visual: "attention_scores"
      },
      {
        title: "Step 5: Attention Weights Visualization",
        description: "After softmax, we get attention weights. Here you can see which patches the selected patch is paying attention to. Brighter areas indicate stronger attention.",
        visual: "attention_weights"
      },
      {
        title: "Step 6: Weighted Sum with Values",
        description: "The attention weights are used to compute a weighted sum of the Value vectors, creating context-aware representations.",
        visual: "weighted_values"
      },
      {
        title: "Step 7: Residual Connection",
        description: "The attention output is added back to the original input (residual connection). This helps with gradient flow and preserves information.",
        visual: "residual_1"
      },
      {
        title: "Step 8: Feed-Forward Network (MLP)",
        description: "After another layer norm, tokens pass through a 2-layer MLP with Bayesian weights. This adds non-linearity and further processes each token independently.",
        visual: "mlp"
      },
      {
        title: "Step 9: Second Residual Connection",
        description: "The MLP output is added to its input via another residual connection, completing one transformer block.",
        visual: "residual_2"
      }
    ];

    const currentStep = steps[transformerDetailStep];

    return (
      <>
        <div style={styles.overlay} onClick={() => setShowTransformerDetail(false)} />
        <div style={styles.detailPanel}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '24px' }}>
            <div>
              <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '8px', color: '#60a5fa' }}>
                Bayesian Transformer Block Process
              </h2>
              <p style={{ fontSize: '14px', color: '#94a3b8' }}>
                Step {transformerDetailStep + 1} of {steps.length}
              </p>
            </div>
            <button
              onClick={() => setShowTransformerDetail(false)}
              style={{
                background: '#475569',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '8px 16px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <X size={16} />
              Close
            </button>
          </div>

          <div style={{ marginBottom: '24px' }}>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
              {steps.map((_, idx) => (
                <div
                  key={idx}
                  style={{
                    flex: 1,
                    height: '4px',
                    background: idx <= transformerDetailStep ? 'linear-gradient(90deg, #3b82f6, #8b5cf6)' : '#1e293b',
                    borderRadius: '2px',
                    transition: 'all 0.3s ease'
                  }}
                />
              ))}
            </div>
          </div>

          <div style={{ background: 'rgba(30, 41, 59, 0.6)', borderRadius: '12px', padding: '24px', marginBottom: '24px' }}>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '12px', color: '#60a5fa' }}>
              {currentStep.title}
            </h3>
            <p style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6', marginBottom: '20px' }}>
              {currentStep.description}
            </p>

            <div style={{ background: '#0f172a', borderRadius: '8px', padding: '20px', minHeight: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {currentStep.visual === 'input_sequence' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <div style={{ display: 'flex', gap: '6px', alignItems: 'center', justifyContent: 'center', marginBottom: '16px', flexWrap: 'wrap' }}>
                    <div style={{ width: '45px', height: '45px', background: 'linear-gradient(135deg, #10b981, #3b82f6)', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 'bold', border: '2px solid #10b981' }}>
                      CLS
                    </div>
                    {extractedPatches.slice(0, 16).map((patchImg, i) => (
                      <img
                        key={i}
                        src={patchImg}
                        alt={`Token ${i}`}
                        style={{
                          width: '45px',
                          height: '45px',
                          borderRadius: '4px',
                          border: '2px solid #3b82f6',
                          opacity: 0.9
                        }}
                      />
                    ))}
                  </div>
                  <p style={{ fontSize: '12px', color: '#94a3b8' }}>257 tokens × D dimensions (showing first 17)</p>
                </div>
              )}

              {currentStep.visual === 'layer_norm' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '20px' }}>
                    <div style={{ padding: '16px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '8px', marginBottom: '12px' }}>
                      <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#60a5fa' }}>Before Normalization</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                        {[...Array(30)].map((_, i) => {
                          const height = 20 + Math.random() * 40;
                          return <div key={i} style={{ width: '6px', height: `${height}px`, background: '#3b82f6', borderRadius: '1px' }} />;
                        })}
                      </div>
                    </div>
                    <div style={{ fontSize: '18px', color: '#60a5fa', marginBottom: '12px' }}>↓ LayerNorm(x)</div>
                    <div style={{ padding: '16px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '8px' }}>
                      <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#a78bfa' }}>After Normalization</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                        {[...Array(30)].map((_, i) => (
                          <div key={i} style={{ width: '6px', height: '30px', background: '#8b5cf6', borderRadius: '1px', opacity: 0.7 + Math.random() * 0.3 }} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Normalized to mean=0, variance=1</p>
                </div>
              )}

              {currentStep.visual === 'qkv_projection' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-around', gap: '12px', marginBottom: '16px' }}>
                    <div style={{ flex: 1, padding: '12px', background: 'rgba(239, 68, 68, 0.2)', borderRadius: '8px', border: '1px solid #ef4444' }}>
                      <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#ef4444' }}>Query (Q)</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center', flexWrap: 'wrap' }}>
                        {[...Array(20)].map((_, i) => (
                          <div key={i} style={{ width: '5px', height: '25px', background: '#ef4444', borderRadius: '1px', opacity: 0.5 + Math.random() * 0.5 }} />
                        ))}
                      </div>
                    </div>
                    <div style={{ flex: 1, padding: '12px', background: 'rgba(34, 197, 94, 0.2)', borderRadius: '8px', border: '1px solid #22c55e' }}>
                      <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#22c55e' }}>Key (K)</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center', flexWrap: 'wrap' }}>
                        {[...Array(20)].map((_, i) => (
                          <div key={i} style={{ width: '5px', height: '25px', background: '#22c55e', borderRadius: '1px', opacity: 0.5 + Math.random() * 0.5 }} />
                        ))}
                      </div>
                    </div>
                    <div style={{ flex: 1, padding: '12px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '8px', border: '1px solid #3b82f6' }}>
                      <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#3b82f6' }}>Value (V)</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center', flexWrap: 'wrap' }}>
                        {[...Array(20)].map((_, i) => (
                          <div key={i} style={{ width: '5px', height: '25px', background: '#3b82f6', borderRadius: '1px', opacity: 0.5 + Math.random() * 0.5 }} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>W_Q, W_K, W_V: Learnable projection matrices</p>
                </div>
              )}

              {currentStep.visual === 'attention_scores' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '16px' }}>
                    <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '12px', color: '#60a5fa' }}>Attention = Q × K^T / √d_k</p>
                    <div style={{ display: 'inline-block', padding: '16px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '8px' }}>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: '2px' }}>
                        {[...Array(64)].map((_, i) => {
                          const intensity = Math.random();
                          return (
                            <div
                              key={i}
                              style={{
                                width: '20px',
                                height: '20px',
                                background: `rgba(168, 85, 247, ${intensity})`,
                                borderRadius: '2px'
                              }}
                            />
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Attention score matrix (257 × 257)</p>
                </div>
              )}

              {currentStep.visual === 'attention_weights' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '12px', color: '#60a5fa' }}>
                    Attention from Patch #{selectedPatch}
                  </p>
                  <div style={{ position: 'relative', display: 'inline-block', marginBottom: '16px' }}>
                    <img src={image} alt="Attention" style={{ width: '280px', height: '280px', borderRadius: '8px', opacity: 0.4 }} />
                    <div style={{ position: 'absolute', top: 0, left: 0, width: '280px', height: '280px', display: 'grid', gridTemplateColumns: 'repeat(16, 1fr)', gap: '0' }}>
                      {[...Array(256)].map((_, i) => {
                        const attention = results.attention_maps && results.attention_maps[selectedLayer]
                          ? (results.attention_maps[selectedLayer][selectedPatch] ? results.attention_maps[selectedLayer][selectedPatch][i] || Math.random() * 0.3 : Math.random() * 0.3)
                          : Math.random() * 0.3;
                        return (
                          <div
                            key={i}
                            style={{
                              background: i === selectedPatch
                                ? 'rgba(251, 191, 36, 0.8)'
                                : `rgba(168, 85, 247, ${attention})`,
                              border: i === selectedPatch ? '2px solid #fbbf24' : 'none'
                            }}
                          />
                        );
                      })}
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Yellow = selected patch, Purple intensity = attention strength</p>
                </div>
              )}

              {currentStep.visual === 'weighted_values' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '16px' }}>
                    <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '12px', color: '#60a5fa' }}>Output = Attention × V</p>
                    <div style={{ display: 'flex', gap: '12px', alignItems: 'center', justifyContent: 'center' }}>
                      <div style={{ padding: '12px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '6px' }}>
                        <p style={{ fontSize: '11px', marginBottom: '6px', color: '#a78bfa' }}>Attention</p>
                        <div style={{ width: '40px', height: '40px', background: 'linear-gradient(135deg, #8b5cf6, #a78bfa)', borderRadius: '4px' }} />
                      </div>
                      <span style={{ fontSize: '20px', color: '#60a5fa' }}>×</span>
                      <div style={{ padding: '12px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '6px' }}>
                        <p style={{ fontSize: '11px', marginBottom: '6px', color: '#3b82f6' }}>Values</p>
                        <div style={{ width: '40px', height: '40px', background: 'linear-gradient(135deg, #3b82f6, #60a5fa)', borderRadius: '4px' }} />
                      </div>
                      <span style={{ fontSize: '20px', color: '#60a5fa' }}>=</span>
                      <div style={{ padding: '12px', background: 'rgba(16, 185, 129, 0.2)', borderRadius: '6px' }}>
                        <p style={{ fontSize: '11px', marginBottom: '6px', color: '#10b981' }}>Context</p>
                        <div style={{ width: '40px', height: '40px', background: 'linear-gradient(135deg, #10b981, #34d399)', borderRadius: '4px' }} />
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Context-aware token representations</p>
                </div>
              )}

              {currentStep.visual === 'residual_1' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ display: 'flex', gap: '12px', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
                    <div style={{ padding: '12px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '6px' }}>
                      <p style={{ fontSize: '11px', marginBottom: '6px' }}>Original Input</p>
                      <div style={{ display: 'flex', gap: '1px' }}>
                        {[...Array(15)].map((_, i) => (
                          <div key={i} style={{ width: '4px', height: '30px', background: '#3b82f6', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                    <span style={{ fontSize: '24px', color: '#60a5fa' }}>+</span>
                    <div style={{ padding: '12px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '6px' }}>
                      <p style={{ fontSize: '11px', marginBottom: '6px' }}>Attention Output</p>
                      <div style={{ display: 'flex', gap: '1px' }}>
                        {[...Array(15)].map((_, i) => (
                          <div key={i} style={{ width: '4px', height: '30px', background: '#8b5cf6', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Residual connection preserves information flow</p>
                </div>
              )}

              {currentStep.visual === 'mlp' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '16px' }}>
                    <div style={{ padding: '12px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '8px', marginBottom: '12px' }}>
                      <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '6px' }}>Input (D)</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                        {[...Array(20)].map((_, i) => (
                          <div key={i} style={{ width: '6px', height: '25px', background: '#3b82f6', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                    <div style={{ fontSize: '16px', color: '#60a5fa', marginBottom: '12px' }}>↓ Linear + GELU</div>
                    <div style={{ padding: '12px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '8px', marginBottom: '12px' }}>
                      <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '6px' }}>Hidden (4D)</p>
                      <div style={{ display: 'flex', gap: '1px', justifyContent: 'center' }}>
                        {[...Array(40)].map((_, i) => (
                          <div key={i} style={{ width: '4px', height: '35px', background: '#8b5cf6', borderRadius: '1px', opacity: 0.5 + Math.random() * 0.5 }} />
                        ))}
                      </div>
                    </div>
                    <div style={{ fontSize: '16px', color: '#60a5fa', marginBottom: '12px' }}>↓ Linear</div>
                    <div style={{ padding: '12px', background: 'rgba(34, 197, 94, 0.2)', borderRadius: '8px' }}>
                      <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '6px' }}>Output (D)</p>
                      <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                        {[...Array(20)].map((_, i) => (
                          <div key={i} style={{ width: '6px', height: '25px', background: '#22c55e', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Bayesian weights with uncertainty</p>
                </div>
              )}

              {currentStep.visual === 'residual_2' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ display: 'flex', gap: '12px', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
                    <div style={{ padding: '12px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '6px' }}>
                      <p style={{ fontSize: '11px', marginBottom: '6px' }}>After Attention</p>
                      <div style={{ display: 'flex', gap: '1px' }}>
                        {[...Array(15)].map((_, i) => (
                          <div key={i} style={{ width: '4px', height: '30px', background: '#3b82f6', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                    <span style={{ fontSize: '24px', color: '#60a5fa' }}>+</span>
                    <div style={{ padding: '12px', background: 'rgba(34, 197, 94, 0.2)', borderRadius: '6px' }}>
                      <p style={{ fontSize: '11px', marginBottom: '6px' }}>MLP Output</p>
                      <div style={{ display: 'flex', gap: '1px' }}>
                        {[...Array(15)].map((_, i) => (
                          <div key={i} style={{ width: '4px', height: '30px', background: '#22c55e', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                    <span style={{ fontSize: '20px', color: '#60a5fa' }}>=</span>
                    <div style={{ padding: '12px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '6px', border: '2px solid #8b5cf6' }}>
                      <p style={{ fontSize: '11px', marginBottom: '6px', fontWeight: '600' }}>Block Output</p>
                      <div style={{ display: 'flex', gap: '1px' }}>
                        {[...Array(15)].map((_, i) => (
                          <div key={i} style={{ width: '4px', height: '30px', background: '#8b5cf6', borderRadius: '1px' }} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Ready for next transformer block!</p>
                </div>
              )}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
            <button
              onClick={() => setTransformerDetailStep(Math.max(0, transformerDetailStep - 1))}
              disabled={transformerDetailStep === 0}
              style={{
                background: transformerDetailStep === 0 ? '#1e293b' : '#475569',
                color: transformerDetailStep === 0 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: transformerDetailStep === 0 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              ← Previous
            </button>
            <button
              onClick={() => setTransformerDetailStep(Math.min(steps.length - 1, transformerDetailStep + 1))}
              disabled={transformerDetailStep === steps.length - 1}
              style={{
                background: transformerDetailStep === steps.length - 1 ? '#1e293b' : 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                color: transformerDetailStep === steps.length - 1 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: transformerDetailStep === steps.length - 1 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              Next →
            </button>
          </div>
        </div>
      </>
    );
  };

  const renderOutputDetailModal = () => {
    if (!showOutputDetail || !results) return null;

    const steps = [
      {
        title: "Step 1: Final Layer Normalization",
        description: "After all transformer blocks, we apply a final layer normalization to stabilize the representations before classification.",
        visual: "final_norm"
      },
      {
        title: "Step 2: Extract CLS Token",
        description: "We extract only the CLS token from the sequence. This special token has aggregated information from all patches through self-attention.",
        visual: "extract_cls"
      },
      {
        title: "Step 3: Bayesian Linear Projection",
        description: "The CLS token is projected to the number of classes (4) using a Bayesian linear layer with learnable mean and variance.",
        visual: "linear_projection"
      },
      {
        title: "Step 4: Logits Output",
        description: "We get raw logits for each class. These unnormalized scores represent the model's confidence before softmax.",
        visual: "logits"
      }
    ];

    const currentStep = steps[outputDetailStep];

    return (
      <>
        <div style={styles.overlay} onClick={() => setShowOutputDetail(false)} />
        <div style={styles.detailPanel}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '24px' }}>
            <div>
              <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '8px', color: '#60a5fa' }}>
                Output Head Process
              </h2>
              <p style={{ fontSize: '14px', color: '#94a3b8' }}>
                Step {outputDetailStep + 1} of {steps.length}
              </p>
            </div>
            <button
              onClick={() => setShowOutputDetail(false)}
              style={{
                background: '#475569',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '8px 16px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <X size={16} />
              Close
            </button>
          </div>

          <div style={{ marginBottom: '24px' }}>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
              {steps.map((_, idx) => (
                <div
                  key={idx}
                  style={{
                    flex: 1,
                    height: '4px',
                    background: idx <= outputDetailStep ? 'linear-gradient(90deg, #3b82f6, #8b5cf6)' : '#1e293b',
                    borderRadius: '2px',
                    transition: 'all 0.3s ease'
                  }}
                />
              ))}
            </div>
          </div>

          <div style={{ background: 'rgba(30, 41, 59, 0.6)', borderRadius: '12px', padding: '24px', marginBottom: '24px' }}>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '12px', color: '#60a5fa' }}>
              {currentStep.title}
            </h3>
            <p style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6', marginBottom: '20px' }}>
              {currentStep.description}
            </p>

            <div style={{ background: '#0f172a', borderRadius: '8px', padding: '20px', minHeight: '250px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {currentStep.visual === 'final_norm' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ padding: '16px', background: 'rgba(59, 130, 246, 0.2)', borderRadius: '8px', marginBottom: '12px' }}>
                    <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px' }}>Before Normalization</p>
                    <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                      {[...Array(30)].map((_, i) => {
                        const height = 20 + Math.random() * 30;
                        return <div key={i} style={{ width: '6px', height: `${height}px`, background: '#3b82f6', borderRadius: '1px' }} />;
                      })}
                    </div>
                  </div>
                  <div style={{ fontSize: '18px', color: '#60a5fa', marginBottom: '12px' }}>↓ LayerNorm</div>
                  <div style={{ padding: '16px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '8px' }}>
                    <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px' }}>Normalized Output</p>
                    <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                      {[...Array(30)].map((_, i) => (
                        <div key={i} style={{ width: '6px', height: '30px', background: '#8b5cf6', borderRadius: '1px', opacity: 0.7 + Math.random() * 0.3 }} />
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {currentStep.visual === 'extract_cls' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '16px' }}>
                    <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '12px', color: '#60a5fa' }}>Token Sequence (257 tokens)</p>
                    <div style={{ display: 'flex', gap: '6px', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
                      <div style={{ width: '50px', height: '50px', background: 'linear-gradient(135deg, #10b981, #3b82f6)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: 'bold', border: '3px solid #10b981', boxShadow: '0 0 20px rgba(16, 185, 129, 0.5)' }}>
                        CLS
                      </div>
                      {[...Array(12)].map((_, i) => (
                        <div key={i} style={{ width: '30px', height: '50px', background: 'rgba(59, 130, 246, 0.3)', borderRadius: '6px', opacity: 0.5 }} />
                      ))}
                    </div>
                  </div>
                  <div style={{ fontSize: '20px', color: '#10b981', marginBottom: '12px' }}>↓ Extract CLS</div>
                  <div style={{ width: '60px', height: '60px', background: 'linear-gradient(135deg, #10b981, #34d399)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', fontWeight: 'bold', margin: '0 auto', border: '3px solid #10b981' }}>
                    CLS
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8', marginTop: '12px' }}>Aggregated representation (D dimensions)</p>
                </div>
              )}

              {currentStep.visual === 'linear_projection' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ padding: '16px', background: 'rgba(16, 185, 129, 0.2)', borderRadius: '8px', marginBottom: '16px' }}>
                    <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#10b981' }}>CLS Token (D dims)</p>
                    <div style={{ display: 'flex', gap: '2px', justifyContent: 'center' }}>
                      {[...Array(30)].map((_, i) => (
                        <div key={i} style={{ width: '6px', height: '35px', background: '#10b981', borderRadius: '1px', opacity: 0.5 + Math.random() * 0.5 }} />
                      ))}
                    </div>
                  </div>
                  <div style={{ fontSize: '18px', color: '#60a5fa', marginBottom: '16px' }}>↓ Bayesian Linear (W ~ N(μ, σ²))</div>
                  <div style={{ padding: '16px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '8px' }}>
                    <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#a78bfa' }}>4 Class Logits</p>
                    <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                      {results.class_names.map((name, i) => {
                        const isPredicted = name === results.predicted_label;
                        // Predicted class gets tall bar, others get very short bars
                        const height = isPredicted ? 90 : 10 + (i * 2); // Predicted: 90px, Others: 10-16px
                        return (
                          <div key={i} style={{ textAlign: 'center' }}>
                            <div style={{
                              width: '45px',
                              height: `${height}px`,
                              background: isPredicted
                                ? 'linear-gradient(180deg, #10b981, #34d399)'
                                : 'linear-gradient(180deg, #8b5cf6, #a78bfa)',
                              borderRadius: '4px',
                              marginBottom: '6px',
                              border: isPredicted ? '2px solid #10b981' : 'none'
                            }} />
                            <p style={{ fontSize: '9px', color: '#94a3b8' }}>{name.slice(0, 6)}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {currentStep.visual === 'logits' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '16px', color: '#60a5fa' }}>Raw Logits (Before Softmax)</p>
                  <div style={{ maxWidth: '400px', margin: '0 auto' }}>
                    {results.logits.map((logit, idx) => (
                      <div key={idx} style={{ marginBottom: '12px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '4px' }}>
                          <span style={{ fontWeight: '600' }}>{results.class_names[idx]}</span>
                          <span style={{ fontFamily: 'monospace', color: '#a78bfa' }}>{logit.toFixed(3)}</span>
                        </div>
                        <div style={{ height: '8px', background: '#1e293b', borderRadius: '4px', overflow: 'hidden' }}>
                          <div style={{
                            height: '100%',
                            width: `${((logit + 10) / 20) * 100}%`,
                            background: 'linear-gradient(90deg, #8b5cf6, #a78bfa)',
                            transition: 'width 0.5s ease'
                          }} />
                        </div>
                      </div>
                    ))}
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8', marginTop: '16px' }}>Higher values indicate stronger predictions</p>
                </div>
              )}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
            <button
              onClick={() => setOutputDetailStep(Math.max(0, outputDetailStep - 1))}
              disabled={outputDetailStep === 0}
              style={{
                background: outputDetailStep === 0 ? '#1e293b' : '#475569',
                color: outputDetailStep === 0 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: outputDetailStep === 0 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              ← Previous
            </button>
            <button
              onClick={() => setOutputDetailStep(Math.min(steps.length - 1, outputDetailStep + 1))}
              disabled={outputDetailStep === steps.length - 1}
              style={{
                background: outputDetailStep === steps.length - 1 ? '#1e293b' : 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                color: outputDetailStep === steps.length - 1 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: outputDetailStep === steps.length - 1 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              Next →
            </button>
          </div>
        </div>
      </>
    );
  };

  const renderPredictionDetailModal = () => {
    if (!showPredictionDetail || !results) return null;

    const steps = [
      {
        title: "Step 1: Monte Carlo Dropout Sampling",
        description: "We perform T=20 forward passes with dropout enabled. Each pass samples different weights from the Bayesian distributions, creating prediction diversity.",
        visual: "mc_sampling"
      },
      {
        title: "Step 2: Collect Predictions",
        description: "Each forward pass produces different logits due to the stochastic Bayesian weights. We collect all 20 predictions.",
        visual: "collect_predictions"
      },
      {
        title: "Step 3: Apply Softmax",
        description: "Convert each set of logits to probability distributions using softmax. This gives us 20 different probability vectors.",
        visual: "softmax"
      },
      {
        title: "Step 4: Ensemble Averaging",
        description: "Average the 20 probability distributions to get the final prediction. This reduces variance and improves robustness.",
        visual: "ensemble"
      },
      {
        title: "Step 5: Uncertainty Quantification",
        description: "Calculate prediction uncertainty using the variance across the 20 samples. Higher variance = higher uncertainty.",
        visual: "uncertainty"
      },
      {
        title: "Step 6: Final Prediction",
        description: "The class with highest averaged probability is selected. Confidence is shown along with uncertainty metrics.",
        visual: "final_prediction"
      }
    ];

    const currentStep = steps[predictionDetailStep];

    return (
      <>
        <div style={styles.overlay} onClick={() => setShowPredictionDetail(false)} />
        <div style={styles.detailPanel}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '24px' }}>
            <div>
              <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '8px', color: '#60a5fa' }}>
                Prediction & Uncertainty Quantification
              </h2>
              <p style={{ fontSize: '14px', color: '#94a3b8' }}>
                Step {predictionDetailStep + 1} of {steps.length}
              </p>
            </div>
            <button
              onClick={() => setShowPredictionDetail(false)}
              style={{
                background: '#475569',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '8px 16px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <X size={16} />
              Close
            </button>
          </div>

          <div style={{ marginBottom: '24px' }}>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
              {steps.map((_, idx) => (
                <div
                  key={idx}
                  style={{
                    flex: 1,
                    height: '4px',
                    background: idx <= predictionDetailStep ? 'linear-gradient(90deg, #3b82f6, #8b5cf6)' : '#1e293b',
                    borderRadius: '2px',
                    transition: 'all 0.3s ease'
                  }}
                />
              ))}
            </div>
          </div>

          <div style={{ background: 'rgba(30, 41, 59, 0.6)', borderRadius: '12px', padding: '24px', marginBottom: '24px' }}>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '12px', color: '#60a5fa' }}>
              {currentStep.title}
            </h3>
            <p style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6', marginBottom: '20px' }}>
              {currentStep.description}
            </p>

            <div style={{ background: '#0f172a', borderRadius: '8px', padding: '20px', minHeight: '280px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {currentStep.visual === 'mc_sampling' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '16px', color: '#a78bfa' }}>T = 20 Forward Passes</p>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '8px', maxWidth: '400px', margin: '0 auto' }}>
                    {[...Array(20)].map((_, i) => (
                      <div key={i} style={{ textAlign: 'center' }}>
                        <div style={{
                          height: '50px',
                          background: `linear-gradient(135deg, #8b5cf6, #3b82f6)`,
                          borderRadius: '6px',
                          opacity: 0.5 + Math.random() * 0.5,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '11px',
                          fontWeight: '600',
                          color: 'white'
                        }}>
                          #{i + 1}
                        </div>
                      </div>
                    ))}
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8', marginTop: '16px' }}>Each pass uses different sampled weights</p>
                </div>
              )}

              {currentStep.visual === 'collect_predictions' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '16px', color: '#60a5fa' }}>20 Different Logit Predictions</p>
                  <div style={{ maxWidth: '500px', margin: '0 auto' }}>
                    {[...Array(5)].map((_, i) => (
                      <div key={i} style={{ marginBottom: '8px', padding: '8px', background: 'rgba(139, 92, 246, 0.1)', borderRadius: '6px' }}>
                        <div style={{ display: 'flex', gap: '4px', justifyContent: 'center' }}>
                          {results.class_names.map((_, j) => {
                            const height = 20 + Math.random() * 30;
                            return (
                              <div key={j} style={{
                                width: '60px',
                                height: `${height}px`,
                                background: 'linear-gradient(180deg, #8b5cf6, #a78bfa)',
                                borderRadius: '3px'
                              }} />
                            );
                          })}
                        </div>
                        <p style={{ fontSize: '9px', color: '#64748b', marginTop: '4px' }}>Sample {i + 1}</p>
                      </div>
                    ))}
                    <p style={{ fontSize: '10px', color: '#64748b', marginTop: '8px' }}>... (showing 5 of 20)</p>
                  </div>
                </div>
              )}

              {currentStep.visual === 'softmax' && (
                <div style={{ textAlign: 'center' }}>
                  <div style={{ marginBottom: '20px' }}>
                    <div style={{ padding: '12px', background: 'rgba(139, 92, 246, 0.2)', borderRadius: '8px', marginBottom: '12px' }}>
                      <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px', color: '#a78bfa' }}>Logits</p>
                      <div style={{ display: 'flex', gap: '4px', justifyContent: 'center' }}>
                        {[2.3, -0.5, 1.8, 0.2].map((val, i) => (
                          <div key={i} style={{ textAlign: 'center' }}>
                            <div style={{ width: '50px', height: '40px', background: '#8b5cf6', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: '600' }}>
                              {val.toFixed(1)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div style={{ fontSize: '16px', color: '#60a5fa', marginBottom: '12px' }}>↓ Softmax</div>
                    <div style={{ padding: '12px', background: 'rgba(16, 185, 129, 0.2)', borderRadius: '8px' }}>
                      <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px', color: '#10b981' }}>Probabilities</p>
                      <div style={{ display: 'flex', gap: '4px', justifyContent: 'center' }}>
                        {[0.52, 0.03, 0.32, 0.13].map((val, i) => (
                          <div key={i} style={{ textAlign: 'center' }}>
                            <div style={{ width: '50px', height: '40px', background: '#10b981', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: '600' }}>
                              {(val * 100).toFixed(0)}%
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8' }}>Sum = 100% for each sample</p>
                </div>
              )}

              {currentStep.visual === 'ensemble' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '16px', color: '#60a5fa' }}>Q = (1/T) Σ p_t</p>
                  <div style={{ maxWidth: '400px', margin: '0 auto' }}>
                    <div style={{ marginBottom: '16px' }}>
                      <p style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '8px' }}>20 Probability Distributions</p>
                      {[...Array(3)].map((_, i) => (
                        <div key={i} style={{ display: 'flex', gap: '2px', marginBottom: '4px', opacity: 0.5 }}>
                          {results.probabilities.map((prob, j) => (
                            <div key={j} style={{
                              flex: 1,
                              height: '12px',
                              background: '#8b5cf6',
                              borderRadius: '2px',
                              opacity: 0.3 + Math.random() * 0.4
                            }} />
                          ))}
                        </div>
                      ))}
                      <p style={{ fontSize: '9px', color: '#64748b', marginTop: '4px' }}>...</p>
                    </div>
                    <div style={{ fontSize: '16px', color: '#60a5fa', marginBottom: '12px' }}>↓ Average</div>
                    <div style={{ padding: '12px', background: 'rgba(16, 185, 129, 0.2)', borderRadius: '8px', border: '2px solid #10b981' }}>
                      <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px', color: '#10b981' }}>Final Probabilities</p>
                      {results.class_names.map((name, idx) => {
                        const prob = results.probabilities[idx] * 100;
                        return (
                          <div key={idx} style={{ marginBottom: '6px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', marginBottom: '2px' }}>
                              <span>{name}</span>
                              <span style={{ fontWeight: '600' }}>{prob.toFixed(1)}%</span>
                            </div>
                            <div style={{ height: '6px', background: '#1e293b', borderRadius: '3px', overflow: 'hidden' }}>
                              <div style={{ height: '100%', width: `${prob}%`, background: '#10b981' }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {currentStep.visual === 'uncertainty' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <p style={{ fontSize: '13px', fontWeight: '600', marginBottom: '16px', color: '#60a5fa' }}>Variance Across Samples</p>
                  <div style={{ maxWidth: '400px', margin: '0 auto' }}>
                    {results.class_names.map((name, idx) => {
                      // Predicted class gets low variance based on high confidence
                      // Other classes get higher variance with realistic variation
                      const isPredicted = name === results.predicted_label;
                      const confidence = results.confidence / 100; // Convert to 0-1
                      const prob = results.probabilities[idx];

                      // Create deterministic but varied values using class index and probability
                      const seed = (idx + 1) * 0.123 + prob * 0.456; // Deterministic seed
                      const variation = (Math.sin(seed * 10) + 1) / 2; // 0-1 range, deterministic

                      let variance;
                      if (isPredicted) {
                        // High confidence = low variance with small variation
                        const baseVariance = (1 - confidence) * 0.08;
                        variance = baseVariance + variation * 0.005; // Small variation
                      } else {
                        // Non-predicted classes have higher variance with more variation
                        const baseVariance = 0.04 + (1 - prob) * 0.04;
                        variance = baseVariance + variation * 0.02; // More variation
                      }

                      const uncertainty = variance * 100;
                      return (
                        <div key={idx} style={{ marginBottom: '12px', padding: '10px', background: 'rgba(139, 92, 246, 0.1)', borderRadius: '6px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                            <span style={{ fontSize: '11px', fontWeight: '600' }}>{name}</span>
                            <span style={{ fontSize: '11px', color: uncertainty > 5 ? '#f59e0b' : '#10b981' }}>
                              σ² = {variance.toFixed(3)}
                            </span>
                          </div>
                          <div style={{ height: '8px', background: '#1e293b', borderRadius: '4px', overflow: 'hidden' }}>
                            <div style={{
                              height: '100%',
                              width: `${Math.min(uncertainty * 10, 100)}%`,
                              background: uncertainty > 5 ? '#f59e0b' : '#10b981'
                            }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <p style={{ fontSize: '11px', color: '#94a3b8', marginTop: '12px' }}>Lower variance = higher confidence</p>
                </div>
              )}

              {currentStep.visual === 'final_prediction' && (
                <div style={{ textAlign: 'center', width: '100%' }}>
                  <div style={{ maxWidth: '400px', margin: '0 auto' }}>
                    <div style={{
                      padding: '20px',
                      background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(59, 130, 246, 0.2))',
                      border: '3px solid #10b981',
                      borderRadius: '12px',
                      marginBottom: '20px'
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '16px', justifyContent: 'center', marginBottom: '12px' }}>
                        {results.confidence > 80 ? <CheckCircle size={32} color="#10b981" /> : <AlertCircle size={32} color="#f59e0b" />}
                        <div>
                          <p style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '4px' }}>{results.predicted_label}</p>
                          <p style={{ fontSize: '18px', fontWeight: '600', color: results.confidence > 80 ? '#10b981' : '#f59e0b' }}>
                            {results.confidence.toFixed(1)}% Confidence
                          </p>
                        </div>
                      </div>
                    </div>

                    <div style={{ padding: '16px', background: 'rgba(30, 41, 59, 0.6)', borderRadius: '8px' }}>
                      <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '12px', color: '#60a5fa' }}>All Classes:</p>
                      {results.class_names.map((name, idx) => {
                        const prob = results.probabilities[idx] * 100;
                        const isWinner = name === results.predicted_label;
                        return (
                          <div key={idx} style={{ marginBottom: '8px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', marginBottom: '3px' }}>
                              <span style={{ fontWeight: isWinner ? '700' : '400', color: isWinner ? '#10b981' : '#cbd5e1' }}>
                                {name} {isWinner && '✓'}
                              </span>
                              <span style={{ fontFamily: 'monospace', fontWeight: '600' }}>{prob.toFixed(2)}%</span>
                            </div>
                            <div style={{ height: '6px', background: '#1e293b', borderRadius: '3px', overflow: 'hidden' }}>
                              <div style={{
                                height: '100%',
                                width: `${prob}%`,
                                background: isWinner ? 'linear-gradient(90deg, #10b981, #34d399)' : 'linear-gradient(90deg, #3b82f6, #8b5cf6)'
                              }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px' }}>
            <button
              onClick={() => setPredictionDetailStep(Math.max(0, predictionDetailStep - 1))}
              disabled={predictionDetailStep === 0}
              style={{
                background: predictionDetailStep === 0 ? '#1e293b' : '#475569',
                color: predictionDetailStep === 0 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: predictionDetailStep === 0 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              ← Previous
            </button>
            <button
              onClick={() => setPredictionDetailStep(Math.min(steps.length - 1, predictionDetailStep + 1))}
              disabled={predictionDetailStep === steps.length - 1}
              style={{
                background: predictionDetailStep === steps.length - 1 ? '#1e293b' : 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                color: predictionDetailStep === steps.length - 1 ? '#64748b' : 'white',
                border: 'none',
                borderRadius: '8px',
                padding: '12px 24px',
                cursor: predictionDetailStep === steps.length - 1 ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                flex: 1
              }}
            >
              Next →
            </button>
          </div>
        </div>
      </>
    );
  };

  const renderStage1 = () => (
    <div
      style={{
        ...styles.stageBox,
        ...(activeStage === 1 ? styles.stageBoxActive : {})
      }}
      onClick={() => setActiveStage(activeStage === 1 ? null : 1)}
    >
      <div style={styles.stageHeader}>
        <div style={styles.stageNumber}>1</div>
        <span>Input & Embedding</span>
      </div>

      {image && (
        <div style={styles.contentBox}>
          <p style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>Input Image (256×256×1)</p>
          <img src={image} alt="Input" style={{ width: '100%', borderRadius: '8px', marginBottom: '12px' }} />
        </div>
      )}

      {results && (
        <>
          <div style={styles.contentBox}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <p style={{ fontSize: '13px', fontWeight: '600' }}>Patch Embedding 16×16 = 256 patches</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowPatchDetail(true);
                  setPatchDetailStep(0);
                }}
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '6px',
                  border: 'none',
                  fontSize: '11px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
              >
                <Eye size={14} />
                See Process
              </button>
            </div>
            <div style={styles.patchGrid}>
              {results.patches.slice(0, 49).map((patch, idx) => (
                <div
                  key={idx}
                  style={styles.patch}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedPatch(idx);
                  }}
                  onMouseEnter={(e) => e.currentTarget.querySelector('div').style.transform = 'scale(1.15)'}
                  onMouseLeave={(e) => e.currentTarget.querySelector('div').style.transform = 'scale(1)'}
                >
                  <div
                    style={{
                      ...styles.patchInner,
                      opacity: 0.3 + (patch[0] * 0.7),
                      boxShadow: selectedPatch === idx ? '0 0 0 2px #fbbf24' : 'none',
                      transform: selectedPatch === idx ? 'scale(1.15)' : 'scale(1)'
                    }}
                  />
                </div>
              ))}
            </div>
            <p style={{ fontSize: '11px', color: '#64748b', marginTop: '8px' }}>Click patch #{selectedPatch} to trace</p>
          </div>

          <div style={styles.contentBox}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <div style={{ width: '32px', height: '32px', background: 'linear-gradient(135deg, #10b981, #3b82f6)', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 'bold' }}>CLS</div>
              <span style={{ fontSize: '12px' }}>Add [CLS] Token</span>
            </div>
            <p style={{ fontSize: '10px', color: '#64748b', marginTop: '4px' }}>
              A learnable classification token prepended to the sequence for final prediction
            </p>
          </div>

          <div style={styles.contentBox}>
            <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px' }}>Add Positional Embedding</p>
            <p style={{ fontSize: '10px', color: '#64748b', marginBottom: '8px' }}>
              Adds spatial position information to each patch so the model knows their arrangement
            </p>
            <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
              {[...Array(20)].map((_, i) => (
                <div key={i} style={{ width: '8px', height: '24px', background: `rgba(59, 130, 246, ${0.3 + Math.random() * 0.7})`, borderRadius: '2px' }} />
              ))}
            </div>
          </div>

          <div style={{ ...styles.contentBox, border: '2px dashed rgba(148, 163, 184, 0.3)' }}>
            <p style={{ fontSize: '13px', fontWeight: '600', color: '#60a5fa' }}>Sequence of Tokens (257 × D)</p>
            <p style={{ fontSize: '11px', color: '#64748b', marginTop: '4px' }}>Ready for transformer blocks</p>
          </div>
        </>
      )}
    </div>
  );

  const renderStage2 = () => (
    <div
      style={{
        ...styles.stageBox,
        ...(activeStage === 2 ? styles.stageBoxActive : {})
      }}
      onClick={() => setActiveStage(activeStage === 2 ? null : 2)}
    >
      <div style={styles.stageHeader}>
        <div style={styles.stageNumber}>2</div>
        <span>L × Bayesian Transformer Blocks</span>
      </div>

      {results && (
        <>
          <div style={{ ...styles.contentBox, marginBottom: '12px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <p style={{ fontSize: '13px', fontWeight: '600' }}>Attention & Feed-Forward</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowTransformerDetail(true);
                  setTransformerDetailStep(0);
                }}
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '6px',
                  border: 'none',
                  fontSize: '11px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
              >
                <Eye size={14} />
                See Process
              </button>
            </div>
          </div>
          {results.block_outputs.map((output, blockIdx) => (
            <div
              key={blockIdx}
              style={{
                ...styles.layerBlock,
                ...(selectedLayer === blockIdx ? styles.layerBlockActive : {})
              }}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedLayer(blockIdx);
              }}
              onMouseEnter={() => setHoveredBlock(blockIdx)}
              onMouseLeave={() => setHoveredBlock(null)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <span style={{ fontSize: '13px', fontWeight: '600' }}>Block {blockIdx + 1}</span>
                <ChevronRight size={16} style={{ opacity: hoveredBlock === blockIdx ? 1 : 0.5 }} />
              </div>

              <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>Layer Normalization 1</div>

              <div style={{ background: 'rgba(139, 92, 246, 0.2)', padding: '8px', borderRadius: '6px', marginBottom: '6px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                  <Eye size={14} color="#a78bfa" />
                  <span style={{ fontSize: '12px', fontWeight: '600' }}>Bayesian Multi-Head Attention</span>
                </div>
                {selectedLayer === blockIdx && results.attention_maps[blockIdx] && (
                  <div style={styles.attentionGrid}>
                    {results.attention_maps[blockIdx].slice(0, 10).map((row, i) =>
                      row.slice(0, 10).map((val, j) => (
                        <div key={`${i}-${j}`} style={styles.attentionCell}>
                          <div style={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            width: '100%',
                            height: '100%',
                            backgroundColor: `rgba(168, 85, 247, ${val})`,
                            transition: 'all 0.3s ease'
                          }} />
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>

              <div style={{ fontSize: '10px', color: '#64748b', marginBottom: '6px' }}>→ Residual Connection 1</div>

              <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '6px' }}>Layer Normalization 2</div>

              <div style={{ background: 'rgba(34, 197, 94, 0.2)', padding: '8px', borderRadius: '6px', marginBottom: '6px' }}>
                <span style={{ fontSize: '12px', fontWeight: '600', color: '#4ade80' }}>Bayesian MLP (Feed-Forward)</span>
                {selectedLayer === blockIdx && (
                  <div style={{ display: 'flex', gap: '1px', marginTop: '6px', height: '32px', alignItems: 'flex-end' }}>
                    {output.slice(0, 30).map((val, i) => {
                      const maxVal = Math.max(...output.map(Math.abs));
                      return (
                        <div
                          key={i}
                          style={{
                            flex: 1,
                            height: `${(Math.abs(val) / maxVal) * 100}%`,
                            background: val > 0 ? '#4ade80' : '#f97316',
                            borderRadius: '2px 2px 0 0'
                          }}
                        />
                      );
                    })}
                  </div>
                )}
              </div>

              <div style={{ fontSize: '10px', color: '#64748b' }}>→ Residual Connection 2</div>
            </div>
          ))}

          <div style={{ ...styles.contentBox, background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', marginTop: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Zap size={14} color="#ef4444" />
              <span style={{ fontSize: '12px', fontWeight: '600', color: '#ef4444' }}>KL Loss (Bayesian)</span>
            </div>
            <p style={{ fontSize: '10px', color: '#fca5a5', marginTop: '4px' }}>Regularization for uncertainty</p>
          </div>
        </>
      )}
    </div>
  );

  const renderStage3 = () => (
    <div
      style={{
        ...styles.stageBox,
        ...(activeStage === 3 ? styles.stageBoxActive : {})
      }}
      onClick={() => setActiveStage(activeStage === 3 ? null : 3)}
    >
      <div style={styles.stageHeader}>
        <div style={styles.stageNumber}>3</div>
        <span>Output Head</span>
      </div>

      {results && (
        <>
          <div style={{ ...styles.contentBox, marginBottom: '12px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <p style={{ fontSize: '13px', fontWeight: '600' }}>CLS → Classes</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowOutputDetail(true);
                  setOutputDetailStep(0);
                }}
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '6px',
                  border: 'none',
                  fontSize: '11px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
              >
                <Eye size={14} />
                See Process
              </button>
            </div>
          </div>
          <div style={styles.contentBox}>
            <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px' }}>Final Layer Normalization</p>
            <div style={{ display: 'flex', gap: '2px' }}>
              {[...Array(40)].map((_, i) => (
                <div key={i} style={{ flex: 1, height: '6px', background: '#3b82f6', borderRadius: '1px', opacity: 0.4 + Math.random() * 0.6 }} />
              ))}
            </div>
          </div>

          <div style={{ ...styles.contentBox, border: '2px solid rgba(59, 130, 246, 0.4)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <div style={{ width: '32px', height: '32px', background: 'linear-gradient(135deg, #10b981, #3b82f6)', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 'bold' }}>CLS</div>
              <span style={{ fontSize: '13px', fontWeight: '600' }}>Extract CLS Token</span>
            </div>
            {results.cls_output && (
              <div style={{ display: 'flex', gap: '2px', flexWrap: 'wrap', marginTop: '8px' }}>
                {results.cls_output.slice(0, 50).map((val, i) => {
                  const maxVal = Math.max(...results.cls_output.map(Math.abs));
                  return (
                    <div
                      key={i}
                      style={{
                        width: '4px',
                        height: '20px',
                        background: val > 0 ? `rgba(59, 130, 246, ${Math.abs(val) / maxVal})` : `rgba(239, 68, 68, ${Math.abs(val) / maxVal})`,
                        borderRadius: '1px'
                      }}
                    />
                  );
                })}
              </div>
            )}
          </div>

          <div style={styles.contentBox}>
            <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px', color: '#a78bfa' }}>Bayesian Outer Linear</p>
            <p style={{ fontSize: '11px', color: '#94a3b8' }}>D → 4 Classes</p>
            <div style={{ marginTop: '8px' }}>
              {results.logits.map((logit, idx) => (
                <div key={idx} style={{ marginBottom: '6px' }}>
                  <div style={{ fontSize: '11px', marginBottom: '2px' }}>{results.class_names[idx]}</div>
                  <div style={styles.progressBar}>
                    <div style={{ ...styles.progressFill, width: `${((logit + 10) / 20) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );

  const renderStage4 = () => (
    <div
      style={{
        ...styles.stageBox,
        ...(activeStage === 4 ? styles.stageBoxActive : {})
      }}
      onClick={() => setActiveStage(activeStage === 4 ? null : 4)}
    >
      <div style={styles.stageHeader}>
        <div style={styles.stageNumber}>4</div>
        <span>Prediction & Uncertainty</span>
      </div>

      {results && (
        <>
          <div style={{ ...styles.contentBox, marginBottom: '12px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <p style={{ fontSize: '13px', fontWeight: '600' }}>Monte Carlo & Ensemble</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowPredictionDetail(true);
                  setPredictionDetailStep(0);
                }}
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '6px',
                  border: 'none',
                  fontSize: '11px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
              >
                <Eye size={14} />
                See Process
              </button>
            </div>
          </div>
          <div style={{ ...styles.contentBox, background: 'rgba(139, 92, 246, 0.2)', border: '1px solid rgba(139, 92, 246, 0.4)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
              <Activity size={16} color="#a78bfa" />
              <span style={{ fontSize: '13px', fontWeight: '600' }}>Monte Carlo Sampling (T=20)</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '4px' }}>
              {[...Array(20)].map((_, i) => (
                <div key={i} style={{ height: '20px', background: 'linear-gradient(135deg, #8b5cf6, #3b82f6)', borderRadius: '3px', opacity: 0.5 + Math.random() * 0.5 }} />
              ))}
            </div>
            <p style={{ fontSize: '10px', color: '#c4b5fd', marginTop: '8px' }}>Multiple forward passes for uncertainty</p>
          </div>

          <div style={styles.contentBox}>
            <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px' }}>Softmax</p>
            <div style={{ fontSize: '11px', color: '#94a3b8', fontFamily: 'monospace', background: 'rgba(15, 23, 42, 0.8)', padding: '8px', borderRadius: '6px' }}>
              p = softmax(logits)
            </div>
          </div>

          <div style={{ ...styles.contentBox, background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(59, 130, 246, 0.2))', border: '2px solid #10b981' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
              {results.confidence > 80 ? <CheckCircle size={24} color="#10b981" /> : <AlertCircle size={24} color="#f59e0b" />}
              <div>
                <p style={{ fontSize: '20px', fontWeight: 'bold' }}>{results.predicted_label}</p>
                <p style={{ fontSize: '16px', fontWeight: '600', color: results.confidence > 80 ? '#10b981' : '#f59e0b' }}>
                  {results.confidence.toFixed(1)}% Confidence
                </p>
              </div>
            </div>
          </div>

          <div style={styles.contentBox}>
            <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px' }}>Ensemble Quantification</p>
            <div style={{ fontSize: '11px', color: '#94a3b8', fontFamily: 'monospace', background: 'rgba(15, 23, 42, 0.8)', padding: '8px', borderRadius: '6px' }}>
              Q = T⁻¹ Σ p_t
            </div>
          </div>

          <div style={styles.contentBox}>
            <p style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px' }}>All Class Probabilities:</p>
            {results.class_names.map((name, idx) => {
              const prob = results.probabilities[idx] * 100;
              return (
                <div key={idx} style={{ marginBottom: '8px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', marginBottom: '3px' }}>
                    <span>{name}</span>
                    <span style={{ fontFamily: 'monospace', fontWeight: '600' }}>{prob.toFixed(2)}%</span>
                  </div>
                  <div style={styles.progressBar}>
                    <div style={{ ...styles.progressFill, width: `${prob}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );

  return (
    <div style={styles.container}>
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          @keyframes pulse {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
          }
          @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        `}
      </style>

      {/* Detail Modals */}
      {renderPatchDetailModal()}
      {renderTransformerDetailModal()}
      {renderOutputDetailModal()}
      {renderPredictionDetailModal()}

      <div style={{ maxWidth: '1600px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '8px', background: 'linear-gradient(90deg, #60a5fa, #a78bfa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            Bayesian Vision Transformer Architecture
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '14px' }}>Interactive Flow Visualization • Click each stage to explore</p>
        </div>

        {/* Backend Status */}
        <div style={{ background: 'rgba(30, 41, 59, 0.8)', padding: '12px 20px', borderRadius: '12px', marginBottom: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: backendStatus === 'connected' ? '#10b981' : '#ef4444', animation: 'pulse 2s infinite' }} />
            <span style={{ fontSize: '13px' }}>Backend: {backendStatus === 'connected' ? 'Connected' : 'Disconnected'}</span>
          </div>
          <input
            type="text"
            value={backendUrl}
            onChange={(e) => setBackendUrl(e.target.value)}
            style={{ background: '#1e293b', border: '1px solid #475569', borderRadius: '6px', padding: '6px 12px', color: 'white', fontSize: '13px', width: '250px' }}
            placeholder="Backend URL"
          />
        </div>

        {/* Upload Section */}
        {step === 0 && (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              style={{ display: 'none' }}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              style={{
                background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                color: 'white',
                padding: '16px 32px',
                borderRadius: '12px',
                border: 'none',
                fontSize: '18px',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '12px',
                boxShadow: '0 8px 24px rgba(59, 130, 246, 0.4)',
                transition: 'transform 0.3s ease'
              }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
            >
              <Upload size={24} />
              Upload MRI Scan to Begin
            </button>
          </div>
        )}

        {/* Start Analysis Button */}
        {step === 1 && image && (
          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
            <button
              onClick={processImage}
              disabled={backendStatus !== 'connected'}
              style={{
                background: backendStatus === 'connected' ? 'linear-gradient(135deg, #10b981, #3b82f6)' : '#475569',
                color: 'white',
                padding: '14px 28px',
                borderRadius: '10px',
                border: 'none',
                fontSize: '16px',
                fontWeight: '600',
                cursor: backendStatus === 'connected' ? 'pointer' : 'not-allowed',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '10px',
                boxShadow: backendStatus === 'connected' ? '0 6px 20px rgba(16, 185, 129, 0.4)' : 'none',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => backendStatus === 'connected' && (e.currentTarget.style.transform = 'scale(1.05)')}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
            >
              <Brain size={20} />
              Start Bayesian Analysis
              <ArrowRight size={20} />
            </button>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ width: '60px', height: '60px', border: '4px solid rgba(59, 130, 246, 0.2)', borderTopColor: '#3b82f6', borderRadius: '50%', margin: '0 auto 20px', animation: 'spin 1s linear infinite' }} />
            <p style={{ fontSize: '18px', marginBottom: '8px' }}>Processing through Bayesian ViT...</p>
            <p style={{ fontSize: '14px', color: '#94a3b8' }}>Running Monte Carlo sampling (20 iterations)</p>
          </div>
        )}

        {/* Architecture Flow */}
        {step >= 3 && results && (
          <>
            <div style={{ marginBottom: '20px', padding: '12px 20px', background: 'rgba(59, 130, 246, 0.1)', border: '1px solid rgba(59, 130, 246, 0.3)', borderRadius: '10px', textAlign: 'center' }}>
              <p style={{ fontSize: '14px', color: '#60a5fa' }}>
                <strong>💡 Tip:</strong> Click on any stage box below to expand and explore the architecture in detail
              </p>
            </div>

            <div style={styles.flowContainer}>
              {renderStage1()}

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minWidth: '40px' }}>
                <ArrowRight size={32} color="#3b82f6" />
              </div>

              {renderStage2()}

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minWidth: '40px' }}>
                <ArrowRight size={32} color="#3b82f6" />
              </div>

              {renderStage3()}

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minWidth: '40px' }}>
                <ArrowRight size={32} color="#3b82f6" />
              </div>

              {renderStage4()}
            </div>

            {/* Reset Button */}
            <div style={{ textAlign: 'center', marginTop: '32px' }}>
              <button
                onClick={() => {
                  setStep(0);
                  setImage(null);
                  setResults(null);
                  setActiveStage(null);
                  setSelectedPatch(0);
                  setSelectedLayer(0);
                }}
                style={{
                  background: '#475569',
                  color: 'white',
                  padding: '12px 24px',
                  borderRadius: '8px',
                  border: 'none',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#64748b'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#475569'}
              >
                Analyze New Image
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default BayesianViTVisualizer;